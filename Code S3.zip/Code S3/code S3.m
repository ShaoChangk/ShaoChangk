I = imread('****.jpg');
level=graythresh(I);
%level=0.8;
I = im2bw(I,level); 
I2=imcomplement(I);
I=double(I);
I2=double(I2);
I3=zeros(768,1024);
%surf(I2);
for i=2:768
    for j=2:1024
        if(I2(i,j)==1&&(I2(i+1,j)==0||I2(i-1,j)==0||I2(i,j+1)==0||I2(i,j-1)==0))
            I3(i,j)=I2(i,j);
        end
    end
end
%surf(I3);
[y,x]=find(I3==1);
totalpix=length(x);
cent=zeros(768,1024);
for i1=1:totalpix-1
    for i2=i1+1:totalpix
        x1=round((x(i1)+x(i2))/2);
        y1=round((y(i1)+y(i2))/2);
        I3(y1,x1)=I3(y1,x1)+1;
    end
end
cent=max(max(I3));
[y_max,x_max]=find(I3==max(I3(:)));%find center

dis=zeros(1,totalpix);
for i3=1:totalpix
    dis(1,i3)=((x(i3)-x_max)^2+(y(i3)-y_max)^2)^0.5;
end
dis_average=mean(dis);
dis_abs=abs(dis-dis_average);
rough=sum(dis_abs)/totalpix;
bili=rough/dis_average;